<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
jsonHeader();



$bi = noHacking(isset($data['bi']) ? $data['bi'] : '');


$sql = "SELECT * FROM history WHERE bi_user='$bi'";
$exec = mysqli_query($connect, $sql);


$i = 0;
$j = [];
if (mysqli_num_rows($exec) > 0) {



  while ($data = mysqli_fetch_assoc($exec)) {
    $j[$i] = [
      "id" => intval($data['id']),
      "description" => $data['description'],
      "price" => $data['price'],
      "date" => $data['date'],
      "type" => $data['type'],


    ];
    $i++;
  }
  echo json_encode(["response" => true, "items" => $j]);




} else {

  echo json_encode(["response" => false, "items" => $j]);
}







?>