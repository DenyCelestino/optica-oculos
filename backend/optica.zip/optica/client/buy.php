<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
jsonHeader();


$name = noHacking(isset($data['name']) ? $data['name'] : '');
$email = noHacking(isset($data['email']) ? $data['email'] : '');
$bi = noHacking(isset($data['bi']) ? $data['bi'] : '');
$phone = noHacking(isset($data['phone']) ? $data['phone'] : '');
$product = noHacking(isset($data['product']) ? $data['product'] : '');
$productname = noHacking(isset($data['productname']) ? $data['productname'] : '');
$productprice = noHacking(isset($data['productprice']) ? $data['productprice'] : '');
$quantity = noHacking(isset($data['quantity']) ? $data['quantity'] : '');
$date = datenow();




$sql = "INSERT INTO `buy`( `id_product`, `name`, `bi_number`, `email`, `number`,`quantity`) VALUES ('$product','$name','$bi','$email','$phone','$quantity')";

$exec = mysqli_query($connect, $sql);
if (mysqli_affected_rows($connect) == 1) {
  echo json_encode(true);

  $sql = "INSERT INTO `history`(`description`, `bi_user`, `price`, `date`) VALUES ('Comprou Oculos $productname','$bi','$productprice','$date')";

  mysqli_query($connect, $sql);

  $sql = "UPDATE products set quantity=quantity-'$quantity'";
  mysqli_query($connect, $sql);

} else {
  echo json_encode(false);
}

mysqli_close($connect);







?>