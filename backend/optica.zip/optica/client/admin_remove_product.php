<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
jsonHeader();




$product = noHacking(isset($data['product']) ? $data['product'] : '');
$oldimage = noHacking(isset($data['oldimage']) ? $data['oldimage'] : '');





$sql = "DELETE FROM `products` WHERE id='$product'";

$query = mysqli_query($connect, $sql);
if (mysqli_affected_rows($connect) == 1) {


  if (file_exists($oldimage) == true) {

    unlink($oldimage);
  }

  echo json_encode(true);


} else {
  echo json_encode(false);
}


mysqli_close($connect);




?>