<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
jsonHeader();


$name = noHacking(isset($data['name']) ? $data['name'] : '');
$bi = noHacking(isset($data['bi']) ? $data['bi'] : '');
$phone = noHacking(isset($data['phone']) ? $data['phone'] : '');
$date = noHacking(isset($data['date']) ? $data['date'] : '');
$today = datesimple();


if ($date == $today || $date < $today) {
  echo json_encode('invalid date');
} else {


  $sql = "SELECT * FROM schedule WHERE bi_number='$bi' AND date='$date'";
  $exec = mysqli_query($connect, $sql);

  if (mysqli_num_rows($exec) > 0) {

    echo json_encode('have');
  } else {

    $sql = "INSERT INTO `schedule`(`name`, `bi_number`, `date`, `phone`) VALUES ('$name','$bi','$date','$phone')";

    $exec = mysqli_query($connect, $sql);
    if (mysqli_affected_rows($connect) == 1) {
      echo json_encode(true);

    } else {
      echo json_encode(false);
    }
  }




}



mysqli_close($connect);







?>