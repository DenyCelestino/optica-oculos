<?php 
include 'config.php';
include 'function.php';  
$url=file_get_contents('php://input');
$data=json_decode($url,true);
jsonHeader();


$email=noHacking(decodeHash(isset($data['email'])?$data['email']:''));
$senha=noHacking(isset($data['senha'])?$data['senha']:'');


$sql = "SELECT * FROM users WHERE email='$email' AND password='$senha'";
$exec=mysqli_query($connect,$sql);


$i=0;
$j=[];
if(mysqli_num_rows($exec)>0){

$data=mysqli_fetch_assoc($exec);
$avatar=NULL;
if($data['avatar']==NULL){
  $avatar='';
}else{
  $avatar=$data['avatar'];
}

echo json_encode(["response"=>true,"t"=>encodeHash($data['id']),
"n"=>encodeHash($data['name']),
"e"=>encodeHash($data['email']),
"ti"=>encodeHash($data['title']),
"a"=>$avatar,
"b"=>encodeHash($data['backdrop']),
"s"=>$data['slug'],
"p"=>getProvinceName($data['province']),
"bio"=>encodeHash($data['biografia']),
"d"=>getDistrictName($data['district']),
"f"=>boolval($data['isfreelancer']),
"status"=>boolval($data['status'])]);


}else{
  echo json_encode(["response"=>false,"data"=>$j]);
}


function getProvinceName($id){
  global $connect;

  $sql = "SELECT * FROM provinces WHERE id='$id'";
  $exec=mysqli_query($connect,$sql);

   $data = mysqli_fetch_assoc($exec);

   return encodeHash($data['name']);

}
function getDistrictName($id){
  global $connect;

  $sql = "SELECT * FROM districts WHERE id='$id'";
  $exec=mysqli_query($connect,$sql);

   $data = mysqli_fetch_assoc($exec);

   return encodeHash($data['name']);

}


?>