<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
jsonHeader();


$id = noHacking(isset($data['id']) ? $data['id'] : '');


$sql = "SELECT * FROM products WHERE id='$id'";
$exec = mysqli_query($connect, $sql);

if (mysqli_num_rows($exec) > 0) {

  $data = mysqli_fetch_assoc($exec);
  echo json_encode($data);

} else {
  echo json_encode($data);
}





?>