<?php
include 'config.php';
include 'function.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
jsonHeader();


$httpPost = file_get_contents("php://input");
$req = json_decode(($httpPost));
$data = json_decode($httpPost, TRUE);
$base = isset($req->image) ? base64_decode($req->image) : '';


$id = noHacking(isset($data['id']) ? $data['id'] : '');
$productname = noHacking(isset($data['productname']) ? $data['productname'] : '');
$description = noHacking(isset($data['description']) ? $data['description'] : '');
$price = noHacking(isset($data['price']) ? $data['price'] : '');
$quantity = noHacking(isset($data['quantity']) ? $data['quantity'] : '');
$oldimage = noHacking(isset($data['oldimage']) ? $data['oldimage'] : '');




if (!empty($base)) {
  $path = 'images/products/' . $data['name'] . uniqid() . "." . $data['format'];
  if (file_put_contents($path, $base)) {

    $sql = "UPDATE `products` SET `name`='$productname',`description`='$description',`price`='$price',`quantity`='$quantity',`image`='$path' WHERE id='$id'";

    $query = mysqli_query($connect, $sql);
    if (mysqli_affected_rows($connect) == 1) {


      if (file_exists($oldimage) == true) {

        unlink($oldimage);
      }

      echo json_encode(["response" => true, "image" => $path]);


    } else {
      echo json_encode(["response" => false]);
    }

  } else {
    echo json_encode('not moved');
  }

} else {
  $sql = "UPDATE `products` SET `name`='$productname',`description`='$description',`price`='$price',`quantity`='$quantity',`image`='$oldimage' WHERE id='$id'";

  $query = mysqli_query($connect, $sql);
  if (mysqli_affected_rows($connect) == 1) {

    echo json_encode(["response" => true, "image" => $oldimage]);


  } else {
    echo json_encode(["response" => false]);
  }
}



mysqli_close($connect);




?>