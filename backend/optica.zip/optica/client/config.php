<?php 
$database = 'optica';
$server='localhost';
$user='root';
$pass='';
$connect = mysqli_connect($server,$user,$pass,$database);
$connect -> set_charset("utf8mb4");



?>