<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
jsonHeader();





$sql = "SELECT * FROM products";
$exec = mysqli_query($connect, $sql);


$i = 0;
$j = [];
if (mysqli_num_rows($exec) > 0) {

  while ($data = mysqli_fetch_assoc($exec)) {
    $j[$i] = [
      "id" => intval($data['id']),
      "name" => $data['name'],
      "description" => $data['description'],
      "price" => $data['price'],
      "quantity" => $data['quantity'],
      "image" => $data['image'],

    ];
    $i++;
  }
  echo json_encode($j);

} else {
  echo json_encode($j);
}





?>