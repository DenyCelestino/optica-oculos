-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05/06/2023 às 19:43
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `optica`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `buy`
--

CREATE TABLE `buy` (
  `id` int(255) NOT NULL,
  `id_product` int(255) NOT NULL,
  `name` text NOT NULL,
  `bi_number` text NOT NULL,
  `email` text NOT NULL,
  `number` text NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `buy`
--

INSERT INTO `buy` (`id`, `id_product`, `name`, `bi_number`, `email`, `number`, `quantity`) VALUES
(1, 2, 'Delfim Celestino', '424256242352N', 'denycelestino21@gmail.com', '844505131', 2),
(2, 2, 'Delfim Celestino', '424256242352N', 'denycelestino21@gmail.com', '844505131', 2),
(3, 1, 'Deny Celestino', '2423423423N', 'denycelestino21@gmail.com', '866460507', 1),
(4, 1, 'Deny Celestino', '2423423423N', 'denycelestino21@gmail.com', '866460507', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `history`
--

CREATE TABLE `history` (
  `id` int(255) NOT NULL,
  `description` text NOT NULL,
  `bi_user` text NOT NULL,
  `price` text NOT NULL,
  `date` datetime NOT NULL,
  `type` text NOT NULL DEFAULT 'buy'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `history`
--

INSERT INTO `history` (`id`, `description`, `bi_user`, `price`, `date`, `type`) VALUES
(1, 'Comprou Oculos LIKE ICE GLASSES', '424256242352N', '1200', '2023-06-05 18:35:03', 'buy'),
(2, 'Comprou Oculos LIKE ICE GLASSES', '424256242352N', '1200', '2023-06-05 18:36:05', 'buy'),
(3, 'Comprou Oculos Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado', '2423423423N', '2500', '2023-06-05 18:36:45', 'buy'),
(4, 'Comprou Oculos Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado', '2423423423N', '2500', '2023-06-05 18:39:15', 'buy');

-- --------------------------------------------------------

--
-- Estrutura para tabela `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `price` text NOT NULL,
  `quantity` int(255) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `quantity`, `image`) VALUES
(1, 'Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado', 'Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado', '2500', 94, 'images/products/48980647de1c805f12.jpg'),
(2, 'LIKE ICE GLASSES', 'Óculos De Grau Rayban Vista Quadrado 0Rx3857Vl Quadrado Óculos.', '1200', 10, 'images/products/54259647df754721aa.jpg'),
(3, 'Óculos de Grau Absurda Bela Vista Feminino 2517', 'Óculos de Grau Absurda Bela Vista Feminino 2517 Óculos de Grau Absurda Bela Vista Feminino 2517 Óculos de Grau Absurda Bela Vista Feminino 2517Óculos de Grau Absurda Bela Vista Feminino 2517Óculos de Grau Absurda Bela Vista Feminino 2517', '3000', 4, 'images/products/94960647de486196ad.jpg'),
(5, 'Óculos de Sol Oakley Quadrado OO9018 Ojector', 'Óculos de Sol Oakley Quadrado OO9018 Ojector Óculos de Sol Oakley Quadrado OO9018 Ojector Óculos de Sol Oakley Quadrado OO9018 Ojector Óculos de Sol Oakley Quadrado OO9018 Ojector', '2500', 14, 'images/products/13335647de9307e894.jpg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `schedule`
--

CREATE TABLE `schedule` (
  `id` int(255) NOT NULL,
  `name` text NOT NULL,
  `bi_number` text NOT NULL,
  `date` date NOT NULL,
  `phone` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `schedule`
--

INSERT INTO `schedule` (`id`, `name`, `bi_number`, `date`, `phone`) VALUES
(2, 'Delfim Celestino', '2423423M', '2023-06-06', '8421225877');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `buy`
--
ALTER TABLE `buy`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `history`
--
ALTER TABLE `history`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `products`
--
ALTER TABLE `products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
